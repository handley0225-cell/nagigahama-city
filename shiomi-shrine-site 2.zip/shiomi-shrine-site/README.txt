# 汐見神社 公式ホームページ（TRPG用・創作）

このフォルダはGitHub Pagesで公開できる静的サイトです。

## ファイル
- index.html：トップページ
- yuisyo.html：由緒・御祭神
- keidai.html：境内案内
- kiroku.html：古記録・伝承
- gyoji.html：祭事・参拝案内
- access.html：交通案内
- style.css：共通デザイン

## GitHubへの追加（iPhone）
1. GitHubで `nagigahama-city` リポジトリを開きます。
2. `Add file` → `Upload files` を選びます。
3. このZIPを展開し、中のHTMLファイル6つと `style.css` をアップロードします（ZIPそのものではなく、中のファイルをアップロード）。
4. Commit changes を押します。
5. 公開後、トップページは `https://handley0225-cell.github.io/nagigahama-city/` です。
6. 由緒など各ページはトップページのメニューから移動できます。

注意：画像はUnsplashの外部画像URLを利用しています。画像の表示にはインターネット接続が必要です。住所・祭事・神社・伝承はすべて架空です。
